insert into tbl_categories (cate_name) values('Jerry');
insert into tbl_categories (cate_name) values('Jenny');
insert into tbl_categories (cate_name) values('King');
insert into tbl_categories (cate_name) values('Panha');

insert into tbl_articles (title,description,author,thumbnail,cate_id) values('title1','description','minea','def.jpg',2);
insert into tbl_articles (title,description,author,thumbnail,cate_id) values('title2','description','minea','def.jpg',2);
insert into tbl_articles (title,description,author,thumbnail,cate_id) values('title3','description','minea','def.jpg',2);
insert into tbl_articles (title,description,author,thumbnail,cate_id) values('title4','description','minea','def.jpg',2);
insert into tbl_articles (title,description,author,thumbnail,cate_id) values('title5','description','minea','def.jpg',2);
