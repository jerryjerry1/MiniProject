package com.example.demo.repository.provider;

import com.example.demo.repository.model.ArticleFilter;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.jdbc.SQL;

public class ArticleProvider {
    public String findAllFilter(ArticleFilter articleFilter){
        return new SQL(){{
            SELECT("a.*,c.cate_name catename");
            FROM("tbl_articles a");
            INNER_JOIN("tbl_categories c on a.cate_id=c.id");
            if(articleFilter.getTitle()!=null)
                WHERE("a.title ILIKE '%'||#{title}||'%'");
            if(articleFilter.getCate_id()!=null)
                WHERE("a.cate_id = #{cate_id}");
        }}.toString();
    }
}
