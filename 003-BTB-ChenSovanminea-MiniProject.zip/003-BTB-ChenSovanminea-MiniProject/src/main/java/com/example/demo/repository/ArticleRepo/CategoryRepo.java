package com.example.demo.repository.ArticleRepo;


import com.example.demo.repository.model.Category;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public interface CategoryRepo {

    @Insert("insert into tbl_categories (cate_name) values(#{name})")
    void add(Category category);

    @Update("update tbl_categories set cate_name = #{name} where id = #{id}")
    void update(Category category);

    @Delete("delete from tbl_categories where id = #{id}")
    void delete(int id);

    @Select("select * from tbl_categories order by id asc")
    @Results({
            @Result(property = "name",column = "cate_name")
    })
    List<Category> findAll();

    @Select("select * from tbl_categories where id = #{id}  order by id asc")
    @Results({
            @Result(property = "name",column = "cate_name")
    })
    Category findById(int id);

    @Select("select id from tbl_categories order by id desc limit 1")
    int getLastId();
}
