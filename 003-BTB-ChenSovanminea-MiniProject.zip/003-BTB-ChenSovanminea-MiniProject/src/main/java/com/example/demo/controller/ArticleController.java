package com.example.demo.controller;

import com.example.demo.repository.model.Article;
import com.example.demo.repository.model.ArticleFilter;
import com.example.demo.repository.model.Category;
import com.example.demo.service.ArticleService.ArticleService;
import com.example.demo.service.ArticleService.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Controller
public class ArticleController {
    @Autowired
    ArticleService articleService;
    @Autowired
    CategoryService categoryService;


    @GetMapping({"/","/home"})
    public String showall(ModelMap modelMap, ArticleFilter articleFilter, @RequestParam(defaultValue = "1") int page, @RequestParam(defaultValue = "5") int limit){
        List<Article> pagingList= new ArrayList<>();
        Article tmp;
        Category cate;
        int startIndex =(page - 1) * limit;
        int endIndex = page*limit;
        int currentPage=1,Allpage,b=0;
        if(articleService.findAllFilter(articleFilter).size()==0) {
            Allpage=1;
        }
        else{
            Allpage = (int) Math.ceil((articleService.findAllFilter(articleFilter).size() /(float)limit));
        }
        for (int i = startIndex; i < endIndex; i++) {
            if (articleService.findAllFilter(articleFilter).size() <= i){
                b=1;
                currentPage = Allpage;
                break;
            }else{
                currentPage=page;
            }
            tmp= new Article();
            cate= new Category();
            tmp.setId(articleService.findAllFilter(articleFilter).get(i).getId());
            tmp.setTitle(articleService.findAllFilter(articleFilter).get(i).getTitle());
            tmp.setDescription(articleService.findAllFilter(articleFilter).get(i).getDescription());
            tmp.setAuthor(articleService.findAllFilter(articleFilter).get(i).getAuthor());
            cate.setId(articleService.findAllFilter(articleFilter).get(i).getCategory().getId());
            cate.setName(articleService.findAllFilter(articleFilter).get(i).getCategory().getName());
            tmp.setCategory(cate);
            System.out.println();
            tmp.setThumbnail(articleService.findAllFilter(articleFilter).get(i).getThumbnail());
            pagingList.add(tmp);
        }
        int next=currentPage+1;
        int prev=currentPage-1;
        if(next>Allpage) next=1;
        if(prev<=0) prev=Allpage;
        modelMap.addAttribute("articles",pagingList);
        modelMap.addAttribute("totalPage",Allpage);
        modelMap.addAttribute("cur",currentPage);
        modelMap.addAttribute("next",next);
        modelMap.addAttribute("prev",prev);
        modelMap.addAttribute("cate",categoryService.findAll());
        return "index";
    }

    @GetMapping ("/formadd")
    public String formadd(ModelMap modelMap){
        modelMap.addAttribute("artical",new Article());
        modelMap.addAttribute("cate",categoryService.findAll());
        return "formadd";
    }
    @PostMapping("/postarticle")
    public String postArticle(@ModelAttribute Article article, @RequestParam MultipartFile file){
        if(!file.isEmpty()){
            String fileName = UUID.randomUUID().toString();
            try {
                int lastIndexOf = file.getOriginalFilename().lastIndexOf(".");
                if (lastIndexOf == -1) {
                    fileName+=""; // empty extension
                }
                fileName+=file.getOriginalFilename().substring(lastIndexOf);
                Files.copy(file.getInputStream(), Paths.get("src/main/resources/static/image",fileName));
                article.setThumbnail(fileName);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

               article.setId(articleService.getLastId());
               articleService.add(article);

        return "redirect:/home";
    }
    @GetMapping("/view/{id}")
    public String view(@PathVariable int id,ModelMap modelMap){
        modelMap.addAttribute("articles",articleService.findbyID(id));
        return "view";
    }

    @GetMapping("/update/{id}")
    public String update(ModelMap modelMap,@PathVariable int id){
        modelMap.addAttribute("articles",articleService.findbyID(id));
        modelMap.addAttribute("artical",new Article());
        return "update";
    }
    @PostMapping("/updatearticle/{id}")
    public String updateArticle(@PathVariable int id,@ModelAttribute Article article,MultipartFile file){
        if(!file.isEmpty()){
            String fileName = UUID.randomUUID().toString();
            try {
                int lastIndexOf = file.getOriginalFilename().lastIndexOf(".");
                if (lastIndexOf == -1) {
                    fileName+=""; // empty extension
                }
                fileName+=file.getOriginalFilename().substring(lastIndexOf);
                Files.copy(file.getInputStream(), Paths.get("src/main/resources/static/image",fileName));
                article.setThumbnail(fileName);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        article.setId(id);
        articleService.update(article);
        return "redirect:/home";
    }

    @GetMapping("/del/{id}")
    public String del(@PathVariable("id") int id){
        articleService.delete(id);
        return "redirect:/home";
    }



}
