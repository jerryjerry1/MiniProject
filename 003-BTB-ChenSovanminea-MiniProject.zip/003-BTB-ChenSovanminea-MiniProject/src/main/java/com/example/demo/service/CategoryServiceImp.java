package com.example.demo.service;

import com.example.demo.repository.ArticleRepo.CategoryRepo;
import com.example.demo.repository.model.Category;
import com.example.demo.service.ArticleService.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CategoryServiceImp implements CategoryService {
    @Autowired
    CategoryRepo categoryRepo;
    @Override
    public void add(Category category) {
        categoryRepo.add(category);
    }

    @Override
    public void update(Category category) {
        categoryRepo.update(category);
    }

    @Override
    public void delete(int id) {
        categoryRepo.delete(id);
    }

    @Override
    public List<Category> findAll() {
        return categoryRepo.findAll();
    }

    @Override
    public Category findById(int id) {
        return categoryRepo.findById(id);
    }

    @Override
    public int getLastId() {
        return categoryRepo.getLastId();
    }
}
