//package com.example.demo.repository;
//
//import com.example.demo.repository.ArticleRepo.ArticleRepo;
//import com.example.demo.repository.model.Article;
//import org.springframework.stereotype.Repository;
//
//import java.util.ArrayList;
//import java.util.List;
//
//@Repository
//public class ArticleRepoImp implements ArticleRepo {
//
//
//    ArrayList<Article> articleList=new ArrayList<>();
//    public ArticleRepoImp(){
//        for (int i=1;i<=15;i++){
//            articleList.add(new Article(i,"title"+i,"des","author",""));
//        }
//    }
//
//    @Override
//    public int getLastId() {
//        return articleList.size()<1?1:articleList.get(articleList.size()-1).getId()+1;
//    }
//
//    @Override
//    public void add(Article article) {
//        articleList.add(article);
//    }
//
//    @Override
//    public void delete(int id) {
//        for(int i=0;i<articleList.size();i++){
//            if(articleList.get(i).getId()==id){
//                articleList.remove(i);
//                return;
//            }
//        }
//    }
//
//    @Override
//    public void update(Article article) {
//        for(int i=0;i<articleList.size();i++){
//            if(articleList.get(i).getId()==article.getId()){
//                articleList.set(i,article);
//                return;
//            }
//        }
//    }
//
//    @Override
//    public ArrayList<Article> findall() {
//        return articleList;
//    }
//
//    @Override
//    public Article findbyID(int id) {
//        Article article=null;
//        for(int i=0;i<articleList.size();i++){
//            if(articleList.get(i).getId()==id){
//                article=articleList.get(i);
//            }
//        }
//        return article;
//
//    }
//}
