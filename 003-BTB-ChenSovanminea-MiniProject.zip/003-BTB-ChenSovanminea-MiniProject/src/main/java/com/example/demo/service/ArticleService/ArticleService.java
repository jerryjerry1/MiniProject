package com.example.demo.service.ArticleService;

import com.example.demo.repository.model.Article;
import com.example.demo.repository.model.ArticleFilter;

import java.util.ArrayList;
import java.util.List;

public interface ArticleService {
    void add(Article article);
    void delete(int id);
    void update(Article article);
    List<Article> findall();
    Article findbyID(int id);
    int getLastId();
    List<Article> findAllFilter(ArticleFilter articleFilter);
}
