package com.example.demo.service;

import com.example.demo.repository.ArticleRepo.ArticleRepo;

import com.example.demo.repository.model.Article;
import com.example.demo.repository.model.ArticleFilter;
import com.example.demo.service.ArticleService.ArticleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ArticleServiceImp implements ArticleService {
    @Autowired
    ArticleRepo articleRepoImp;
    @Override
    public void add(Article article) {
       articleRepoImp.add(article);
    }

    @Override
    public int getLastId() {
        return articleRepoImp.getLastId();
    }

    @Override
    public void delete(int id) {
        articleRepoImp.delete(id);
    }

    @Override
    public void update(Article article) {
        articleRepoImp.update(article);
    }

    @Override
    public List<Article> findall() {
        return articleRepoImp.findAll();
    }

    @Override
    public Article findbyID(int id) {
        return articleRepoImp.findById(id);
    }

    @Override
    public List<Article> findAllFilter(ArticleFilter articleFilter) {
        return articleRepoImp.findAllFilter(articleFilter);
    }
}
