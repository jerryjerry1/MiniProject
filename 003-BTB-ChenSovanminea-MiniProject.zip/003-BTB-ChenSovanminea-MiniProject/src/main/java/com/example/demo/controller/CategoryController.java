package com.example.demo.controller;

import com.example.demo.repository.model.Article;
import com.example.demo.repository.model.Category;
import com.example.demo.service.ArticleService.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.ui.ModelMapExtensionsKt;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import javax.validation.Valid;

@Controller
public class CategoryController {
    @Autowired
    CategoryService categoryService;


    @GetMapping("/category")
    public String show(ModelMap modelMap){
        modelMap.addAttribute("category",categoryService.findAll());
        System.out.println(categoryService.findAll());
        return "category";
    }

    @GetMapping ("/addcategory")
    public String formadd(ModelMap modelMap){
        modelMap.addAttribute("category",new Category());
        return "addcategory";
    }

    @PostMapping("/addcate")
    public String add_(@ModelAttribute Category category, BindingResult bindingResult){
        categoryService.add(category);
        return "redirect:/category";
    }

    @GetMapping("/del_cate/{id}")
    public String del(@PathVariable("id") int id){
        categoryService.delete(id);
        return "redirect:/category";
    }

    //update
    @GetMapping("/update_cate/{id}")
    public String update(@PathVariable int id, ModelMap modelMap){
        modelMap.addAttribute("category",categoryService.findById(id));
        return "updatecategory";
    }
    @PostMapping("/update_cate")
    public String update_(@ModelAttribute Category category, BindingResult bindingResult){

        categoryService.update(category);
        return "redirect:/category";
    }

}
