package com.example.demo.service.ArticleService;

import com.example.demo.repository.model.Category;

import java.util.ArrayList;
import java.util.List;

public interface CategoryService {
    void add(Category article);
    void update(Category article);
    void delete(int id);
    List<Category> findAll();
    Category findById(int id);
    int getLastId();
}
